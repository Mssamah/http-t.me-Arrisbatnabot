import { Database } from "bun:sqlite";

const filename = Bun.env.DATABASE_PATH || "./data.sqlite";
export const db = new Database(filename, { create: true });

db.run("PRAGMA journal_mode = WAL;");
db.run("PRAGMA foreign_keys = ON;");

db.run(`
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_user_id TEXT NOT NULL,
    phone TEXT NOT NULL,
    amount_dzd INTEGER NOT NULL CHECK(amount_dzd > 0),
    payment_reference TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK(status IN (
      'awaiting_payment', 'paid', 'processing',
      'completed', 'failed'
    )) DEFAULT 'awaiting_payment',
    provider_reference TEXT,
    provider_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

db.run(`
  CREATE TABLE IF NOT EXISTS users (
    telegram_user_id TEXT PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

export type Order = {
  id: number;
  telegram_user_id: string;
  phone: string;
  amount_dzd: number;
  payment_reference: string;
  status: string;
  provider_reference: string | null;
  provider_message: string | null;
  created_at: string;
  updated_at: string;
};

export function saveUser(user: {
  id: number;
  username?: string;
  first_name?: string;
}) {
  db.query(`
    INSERT INTO users (telegram_user_id, username, first_name)
    VALUES (?, ?, ?)
    ON CONFLICT(telegram_user_id) DO UPDATE SET
      username = excluded.username,
      first_name = excluded.first_name
  `).run(String(user.id), user.username ?? null, user.first_name ?? null);
}

export function createOrder(input: {
  userId: number;
  phone: string;
  amount: number;
  paymentReference: string;
}) {
  return db.query(`
    INSERT INTO orders
      (telegram_user_id, phone, amount_dzd, payment_reference)
    VALUES (?, ?, ?, ?)
  `).run(
    String(input.userId),
    input.phone,
    input.amount,
    input.paymentReference
  );
}

export function getOrder(id: number): Order | null {
  return db.query("SELECT * FROM orders WHERE id = ?").get(id) as Order | null;
}

export function getUserOrder(id: number, userId: number): Order | null {
  return db.query(
    "SELECT * FROM orders WHERE id = ? AND telegram_user_id = ?"
  ).get(id, String(userId)) as Order | null;
}

export function listUserOrders(userId: number): Order[] {
  return db.query(`
    SELECT * FROM orders
    WHERE telegram_user_id = ?
    ORDER BY id DESC LIMIT 10
  `).all(String(userId)) as Order[];
}

export function listRecentOrders(): Order[] {
  return db.query(
    "SELECT * FROM orders ORDER BY id DESC LIMIT 25"
  ).all() as Order[];
}

export function setOrderStatus(
  id: number,
  status: Order["status"],
  providerReference?: string | null,
  providerMessage?: string | null
) {
  return db.query(`
    UPDATE orders
    SET status = ?,
        provider_reference = COALESCE(?, provider_reference),
        provider_message = COALESCE(?, provider_message),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(status, providerReference ?? null, providerMessage ?? null, id);
}
