import type { Order } from "./db";

export type RechargeResult = {
  success: boolean;
  providerReference?: string;
  message: string;
};

/**
 * Mock is for development only. It does not send real credit.
 * Real API integration must match the official provider documentation.
 */
export async function rechargeWithMobiCash(
  order: Order
): Promise<RechargeResult> {
  const mode = Bun.env.MOBICASH_MODE || "mock";

  if (mode === "mock") {
    return {
      success: true,
      providerReference: `MOCK-${order.id}`,
      message: "عملية تجريبية فقط — لم يتم شحن رصيد حقيقي."
    };
  }

  if (mode !== "api") {
    throw new Error("MOBICASH_MODE must be mock or api");
  }

  if (!Bun.env.MOBICASH_API_URL || !Bun.env.MOBICASH_API_TOKEN) {
    throw new Error("Mobi Cash API credentials are missing");
  }

  throw new Error(
    "موصل Mobi Cash الحقيقي غير مفعّل. يلزم تطبيق عقد API الرسمي قبل تنفيذ الشحن."
  );
}
