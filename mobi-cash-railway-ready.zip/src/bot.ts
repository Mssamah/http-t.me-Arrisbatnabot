import { Bot, InlineKeyboard } from "grammy";
import {
  createOrder, getOrder, getUserOrder,
  listRecentOrders, listUserOrders, saveUser, setOrderStatus
} from "./db";
import { rechargeWithMobiCash } from "./provider";

const token = Bun.env.BOT_TOKEN;
if (!token) throw new Error("BOT_TOKEN is missing");

const adminId = Number(Bun.env.ADMIN_ID || 0);
export const bot = new Bot(token);

const menu = new InlineKeyboard()
  .text("📱 طلب شحن", "new_order")
  .row()
  .text("📦 طلباتي", "my_orders")
  .row()
  .text("ℹ️ المساعدة", "help");

const isAdmin = (id: number) => adminId > 0 && id === adminId;

bot.command("start", async (ctx) => {
  if (ctx.from) saveUser(ctx.from);
  await ctx.reply(
    "مرحباً بك في بوت خدمة الشحن 🇩🇿\nاختر من القائمة:",
    { reply_markup: menu }
  );
});

bot.command("help", async (ctx) => {
  await ctx.reply(
    "إنشاء طلب:\n/buy 0550000000 1000 REF12345678\n\n" +
    "متابعة طلب:\n/status 1\n\n" +
    "لا ترسل كلمة مرور BaridiMob أو رمز OTP أو بيانات البطاقة."
  );
});

bot.callbackQuery("new_order", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.reply("أرسل:\n/buy رقم_الهاتف المبلغ مرجع_الدفع\nمثال:\n/buy 0550000000 1000 REF12345678");
});

bot.callbackQuery("my_orders", async (ctx) => {
  await ctx.answerCallbackQuery();
  if (!ctx.from) return;
  const orders = listUserOrders(ctx.from.id);
  if (!orders.length) return ctx.reply("لا توجد طلبات حتى الآن.");
  await ctx.reply(orders.map(o =>
    `#${o.id} | ${o.phone} | ${o.amount_dzd} دج | ${o.status}`
  ).join("\n"));
});

bot.callbackQuery("help", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.reply("استخدم /buy لطلب شحن و/status لمتابعة طلبك.");
});

bot.command("buy", async (ctx) => {
  if (!ctx.from) return;
  saveUser(ctx.from);
  const parts = ctx.match.trim().split(/\s+/);
  if (parts.length !== 3) {
    return ctx.reply("الصيغة: /buy 0550000000 1000 REF12345678");
  }

  const [phone, amountText, paymentReference] = parts;
  const amount = Number(amountText);

  if (!/^0[567]\d{8}$/.test(phone)) return ctx.reply("رقم الهاتف غير صحيح.");
  if (!Number.isSafeInteger(amount) || amount < 100 || amount > 1000000) {
    return ctx.reply("المبلغ يجب أن يكون بين 100 و1,000,000 دج.");
  }
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(paymentReference)) {
    return ctx.reply("مرجع الدفع غير صالح.");
  }

  try {
    const result = createOrder({
      userId: ctx.from.id, phone, amount, paymentReference
    });
    await ctx.reply(
      `تم تسجيل الطلب #${result.lastInsertRowid}\n` +
      `الهاتف: ${phone}\nالمبلغ: ${amount} دج\n` +
      "الحالة: في انتظار التحقق من الدفع.\n" +
      "إرسال المرجع لا يعني تأكيد الدفع."
    );
    if (adminId > 0) {
      await bot.api.sendMessage(
        adminId,
        `طلب جديد #${result.lastInsertRowid}\n` +
        `المستخدم: ${ctx.from.id}\nالهاتف: ${phone}\n` +
        `المبلغ: ${amount} دج\nالمرجع: ${paymentReference}`
      );
    }
  } catch {
    await ctx.reply("تعذر تسجيل الطلب؛ ربما مرجع الدفع مستخدم سابقاً.");
  }
});

bot.command("status", async (ctx) => {
  if (!ctx.from) return;
  const id = Number(ctx.match.trim());
  if (!Number.isSafeInteger(id) || id < 1) return ctx.reply("استخدم /status 1");
  const order = getUserOrder(id, ctx.from.id);
  if (!order) return ctx.reply("الطلب غير موجود.");
  await ctx.reply(
    `الطلب #${order.id}\nالهاتف: ${order.phone}\n` +
    `المبلغ: ${order.amount_dzd} دج\nالحالة: ${order.status}\n` +
    `${order.provider_message ?? ""}`
  );
});

bot.command("admin", async (ctx) => {
  if (!ctx.from || !isAdmin(ctx.from.id)) return ctx.reply("غير مصرح لك.");
  const orders = listRecentOrders();
  if (!orders.length) return ctx.reply("لا توجد طلبات.");
  await ctx.reply(
    "آخر الطلبات:\n" + orders.map(o =>
      `#${o.id} | ${o.phone} | ${o.amount_dzd} دج | ${o.status}`
    ).join("\n") +
    "\n\nبعد التحقق الفعلي من الدفع استخدم /paid رقم_الطلب"
  );
});

// تأكيد إداري بعد التحقق اليدوي فقط — ليس تحققاً آلياً من BaridiMob.
bot.command("paid", async (ctx) => {
  if (!ctx.from || !isAdmin(ctx.from.id)) return ctx.reply("غير مصرح لك.");
  const id = Number(ctx.match.trim());
  if (!Number.isSafeInteger(id) || id < 1) return ctx.reply("استخدم /paid 1");

  const order = getOrder(id);
  if (!order) return ctx.reply("الطلب غير موجود.");
  if (order.status !== "awaiting_payment") {
    return ctx.reply(`حالة الطلب الحالية: ${order.status}`);
  }

  setOrderStatus(id, "paid");
  setOrderStatus(id, "processing");

  try {
    const current = getOrder(id);
    if (!current) throw new Error("Order not found");
    const result = await rechargeWithMobiCash(current);

    if (!result.success) throw new Error(result.message);

    setOrderStatus(id, "completed", result.providerReference, result.message);
    await ctx.reply(`تمت معالجة #${id}: ${result.message}`);
    await bot.api.sendMessage(
      Number(order.telegram_user_id),
      `تحديث الطلب #${id}: ${result.message}`
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    setOrderStatus(id, "failed", null, message);
    await ctx.reply(
      `تعذر إكمال #${id}: ${message}\nراجع حالة المزود قبل إعادة المحاولة.`
    );
  }
});

bot.catch((err) => console.error("Telegram error:", err.error));
