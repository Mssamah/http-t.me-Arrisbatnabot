import { Hono } from "hono";
import { bot } from "./bot";

const app = new Hono();

app.get("/", (c) => c.json({
  service: "Mobi Cash Telegram Bot",
  status: "running"
}));

app.get("/api/health", (c) => c.json({
  status: "ok",
  timestamp: new Date().toISOString()
}));

const port = Number(Bun.env.PORT || 3000);

const server = Bun.serve({
  port,
  hostname: "0.0.0.0",
  fetch: app.fetch
});

console.log(`HTTP server listening on ${server.hostname}:${server.port}`);

bot.start({
  onStart: (info) => console.log(`Telegram bot @${info.username} started`)
}).catch((error) => {
  console.error("Telegram bot failed to start:", error);
  process.exit(1);
});
