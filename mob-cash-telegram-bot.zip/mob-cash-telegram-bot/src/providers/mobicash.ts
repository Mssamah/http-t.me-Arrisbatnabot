import { config } from "../lib/config";

/**
 * Provider integration placeholder.
 * Replace this function using the official Mobi Cash API documentation.
 * Do not guess the endpoint, payload, authentication, or success response.
 */
export async function rechargeMobiCash(accountRef: string, amount: number) {
  if (!config.mobiCashApiUrl || !config.mobiCashApiToken) {
    throw new Error("Mobi Cash API is not configured yet.");
  }

  // TODO: Implement using the provider's official API specification.
  // Example shape only — intentionally no HTTP request is sent.
  void accountRef;
  void amount;
  throw new Error("Mobi Cash API adapter is awaiting the official API specification.");
}
