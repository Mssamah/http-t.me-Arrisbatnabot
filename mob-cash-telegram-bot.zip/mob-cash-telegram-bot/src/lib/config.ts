function required(name: string): string {
  const value = Bun.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const config = {
  botToken: required("BOT_TOKEN"),
  adminId: Number(required("ADMIN_ID")),
  databasePath: Bun.env.DATABASE_PATH || "./data/bot.sqlite",
  amounts: (Bun.env.TOPUP_AMOUNTS || "500,1000,2000,5000")
    .split(",").map((v) => Number(v.trim())).filter((v) => Number.isFinite(v) && v > 0),
  baridimobRip: Bun.env.BARIDIMOB_RIP || "",
  baridimobName: Bun.env.BARIDIMOB_NAME || "",
  supportUsername: Bun.env.SUPPORT_USERNAME || "",
  mobiCashApiUrl: Bun.env.MOBICASH_API_URL || "",
  mobiCashApiToken: Bun.env.MOBICASH_API_TOKEN || "",
};
