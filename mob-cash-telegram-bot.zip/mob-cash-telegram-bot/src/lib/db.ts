import { Database } from "bun:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

export type OrderStatus =
  | "awaiting_payment"
  | "payment_rejected"
  | "awaiting_provider"
  | "completed"
  | "failed";

export interface Order {
  id: number;
  user_id: number;
  username: string | null;
  amount: number;
  account_ref: string;
  status: OrderStatus;
  provider_ref: string | null;
  created_at: string;
  updated_at: string;
}

export function initDb(path: string) {
  mkdirSync(dirname(path), { recursive: true });
  const db = new Database(path, { create: true });
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      telegram_id INTEGER PRIMARY KEY,
      username TEXT,
      first_name TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      username TEXT,
      amount INTEGER NOT NULL,
      account_ref TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'awaiting_payment',
      provider_ref TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  return {
    db,
    saveUser(id: number, username: string | undefined, firstName: string) {
      db.query(`INSERT INTO users (telegram_id, username, first_name)
        VALUES (?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name`)
        .run(id, username || null, firstName);
    },
    createOrder(userId: number, username: string | undefined, amount: number, accountRef: string) {
      const result = db.query(`INSERT INTO orders (user_id, username, amount, account_ref)
        VALUES (?, ?, ?, ?)`).run(userId, username || null, amount, accountRef);
      return Number(result.lastInsertRowid);
    },
    getOrder(id: number) {
      return db.query("SELECT * FROM orders WHERE id = ?").get(id) as Order | null;
    },
    getUserOrders(userId: number) {
      return db.query("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10")
        .all(userId) as Order[];
    },
    getPendingOrders() {
      return db.query("SELECT * FROM orders WHERE status = 'awaiting_payment' ORDER BY id ASC LIMIT 20")
        .all() as Order[];
    },
    setStatus(id: number, status: OrderStatus, providerRef: string | null = null) {
      db.query(`UPDATE orders SET status = ?, provider_ref = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
        .run(status, providerRef, id);
    },
  };
}

export type Store = ReturnType<typeof initDb>;
